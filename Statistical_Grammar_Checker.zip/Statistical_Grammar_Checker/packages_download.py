from nltk.corpus import reuters

import nltk

nltk.download('reuters')

nltk.download('punkt')

print(reuters.sents())
